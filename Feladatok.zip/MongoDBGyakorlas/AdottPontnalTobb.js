const url="mongodb+srv://t13szeklas:12345asd@cluster0.njg294g.mongodb.net/"
const MongoClient=require("mongodb").MongoClient

async function AdottPontnalTobb(){
    try{
        const client=await MongoClient.connect(url)
        const db=client.db("T13")
        const collection=db.collection("fifa")

        const eredmeny=await collection.find({
            pontszam:{$gte:1600}
        },{projection:{_id:0,csapat:1,pontszam:1}}).sort({pontszam:1}).toArray()

        console.log(eredmeny)
        client.close()
    }
    catch(error){
        console.error("Hiba a művelet végrehajtása során",err)
    }
}
AdottPontnalTobb()