const url="mongodb+srv://t13szeklas:12345asd@cluster0.njg294g.mongodb.net/"
const MongoClient=require("mongodb").MongoClient

async function KollekcioLetrehozas(){
    try{
        const client=await MongoClient.connect(url)
        const db=client.db("T13")
        await db.createCollection("fifa")
        console.log("Kollekció létrehozva")
        client.close()
    }
    catch(error){
        console.error("Hiba a művelet végrehajtása során",err)
    }
}
KollekcioLetrehozas()