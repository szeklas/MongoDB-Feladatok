const url="mongodb+srv://t13szeklas:12345asd@cluster0.njg294g.mongodb.net/"
const MongoClient=require("mongodb").MongoClient

async function HelyezesNemValtozott(){
    try{
        const client=await MongoClient.connect(url)
        const db=client.db("T13")
        const collection=db.collection("fifa")

        const eredmeny=await collection.find({
            valtozas:0
        },{projection:{_id:0}}).sort({helyezes:1}).toArray()

        console.log(eredmeny)
        client.close()
    }
    catch(error){
        console.error("Hiba a művelet végrehajtása során",err)
    }
}
HelyezesNemValtozott()