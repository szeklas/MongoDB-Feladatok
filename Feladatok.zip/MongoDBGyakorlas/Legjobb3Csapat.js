const url="mongodb+srv://t13szeklas:12345asd@cluster0.njg294g.mongodb.net/"
const MongoClient=require("mongodb").MongoClient

async function Legjobb3Csapat(){
    try{
        const client=await MongoClient.connect(url)
        const db=client.db("T13")
        const collection=db.collection("fifa")

        const rendezes={helyezes:1}

        const eredmeny=await collection.find({
            helyezes:{$lte:3}
        },{projection:{_id:0}}).sort(rendezes).toArray()

        console.log(eredmeny)
        client.close()
    }
    catch(error){
        console.error("Hiba a művelet végrehajtása során",err)
    }
}
Legjobb3Csapat()